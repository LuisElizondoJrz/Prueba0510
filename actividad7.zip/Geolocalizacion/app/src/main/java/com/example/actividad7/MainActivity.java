package com.example.actividad7;

import android.Manifest;                                                                                 // acceder a las constantes de permisos de ubicación
import android.content.pm.PackageManager;                                                                // verificar el estado de los permisos
import android.location.Location;                                                                       //ubicación actual
import android.location.LocationListener;                                                                //escuchador de ubicación
import android.location.LocationManager;                                                                    //administrador de ubicación
import android.os.Bundle;                                                                                //una clase que permite pasar datos entre activiades y almacenar datos en un mapa
import android.widget.TextView;                                                                          //muestra texto en la pantalla
import android.widget.Toast;                                                                            //muestra mensajes emergentes en la pantalla

import androidx.annotation.NonNull;                                                                      //importanciones de librerias de la biblioteca de AndroidX
import androidx.appcompat.app.AppCompatActivity;                                                        //actividad de la app
import androidx.core.app.ActivityCompat;                                                                  //permisos de la app

public class MainActivity extends AppCompatActivity implements LocationListener {                       //Define una clase pública llamada MainActivity

    private LocationManager locationManager;                                                            // Declara una variable locationManager que se usará para gestionar las actualizaciones de la ubicación.
    private TextView mensaje;                                                                            // TextView para mostrar la ubicación

    @Override                                                                                             //Indica que este método está sobrescribiendo el método onCreate de la clase base.
    protected void onCreate(Bundle savedInstanceState) {                                                 //Este método se llama cuando se crea la actividad. Es donde se inician los componentes de la interfaz y se establece el diseño.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);                                                          //Establece el diseño de la actividad utilizando el archivo XML activity_main.

        // Inicia el TextView de la UI o interfaz de usuario
        mensaje = findViewById(R.id.mensaje);                                                           // Busca el componente TextView en el diseño utilizando su ID y lo asigna a la variable mensaje.

        // Inicia el servicio de geolocalización
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // Verifica los permisos de ubicación
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED //verifica si los permisos de ubicación han sido concedidos.
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) { //Si no se han concedido, solicita permisos.
            // Solicita los permisos necesarios
            ActivityCompat.requestPermissions(this, new String[]{                                   //Si los permisos no han sido concedidos, solicita al usuario que los otorgue.
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
            }, 1);
        } else {
            // Si los permisos ya están otorgados, solicita actualizaciones de ubicación
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, this); //Si los permisos ya están concedidos, solicita actualizaciones de la ubicación utilizando el proveedor GPS. Los parámetros indican la frecuencia y la distancia mínima entre actualizaciones.
        }
    }

    // Callback (funcion o metodo) cuando la ubicación cambia
    @Override
    public void onLocationChanged(@NonNull Location location) { //Este es el método que se llama cuando la ubicación del dispositivo ha cambiado. El parámetro location contiene información sobre la nueva ubicación.
        // Obtiene latitud y longitud
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();

        // Actualiza el TextView con la ubicación actual
        mensaje.setText("Ubicación actual: " + latitude + ", " + longitude);

        // También muestra un mensaje emergente con la ubicación actual
        Toast.makeText(this, "Ubicación actual: " + latitude + ", " + longitude, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // Manejar cambios de estado
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        // El proveedor ha sido habilitado
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        // El proveedor ha sido deshabilitado
    }

    // Maneja el resultado de la solicitud de permisos
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Si los permisos se concedieron, solicita las actualizaciones de ubicación
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, this);
                }
            } else {
                // Si los permisos no se conceden, muestra un mensaje
                Toast.makeText(this, "Permisos de ubicación denegados", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Detener actualizaciones de ubicación al cerrar la app
        locationManager.removeUpdates(this);
    }
}

